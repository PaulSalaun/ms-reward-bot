 # How to install bot :
  1. Clone repository in prefered folder using :
>`git clone https://github.com/PaulSalaun/ms-reward-bot.git`
  2. Open project in your IDE
  3. Install and configure Python 3.10 interpreter from https://www.python.org/downloads/release/python-31011/
  4. Install all dependencies : 
>```pip install -r requirements.txt```
  5. run main.py

    Bot Selenium to complete ms reward daily quests
    Paul SALAÜN

